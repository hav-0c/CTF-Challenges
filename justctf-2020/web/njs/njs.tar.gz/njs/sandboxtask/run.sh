#!/bin/sh

nginx -g "daemon off;";
